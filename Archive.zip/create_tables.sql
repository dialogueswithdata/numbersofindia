CREATE TABLE items (
        id serial,
        title    varchar(100),
        description text,
        media_type varchar(40),
        url text,
        creation_time timestamp DEFAULT current_timestamp,
        creator_id integer,
        CONSTRAINT item_pk PRIMARY KEY(id)
);


CREATE TABLE people (
        id serial,
        first_name varchar(100),
        last_name varchar(100),
        email  varchar(200),
        image_url text,
        creation_time timestamp DEFAULT current_timestamp,
        CONSTRAINT people_pk PRIMARY KEY(id)
);


